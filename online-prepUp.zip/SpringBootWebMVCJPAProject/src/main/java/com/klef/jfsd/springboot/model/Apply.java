package com.klef.jfsd.springboot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "schedule_table")
public class Apply {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="stu_id")
	private int id;
	@Column(name="stu_name",nullable=false,length = 50)
	private String name;
	@Column(name="stu_gender",nullable=false,length = 10)
	private String gender;
	@Column(name="stu_dob",nullable=false,length = 20)
	private String dateofbirth;
	@Column(name="stu_etb",nullable=false,length = 20)
	private String exam;
	@Column(name="stu_edt",nullable=false,length = 20)
	private String dateofexam;
	
	@Column(name="stu_email",nullable=false,unique = true,length = 30)
	private String email;
	
	@Column(name="stu_location",nullable=false)
	private String location;
	@Column(name="stu_contact",nullable=false,unique = true)
	private String contact;
	@Column(name="stu_active",nullable=false)
	   private boolean active; // true or false
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getExam() {
		return exam;
	}
	public void setExam(String exam) {
		this.exam = exam;
	}
	public String getDateofexam() {
		return dateofexam;
	}
	public void setDateofexam(String dateofexam) {
		this.dateofexam = dateofexam;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
}
