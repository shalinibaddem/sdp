package com.klef.jfsd.springboot.service;

import java.util.*;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Apply;
import com.klef.jfsd.springboot.model.Course;
import com.klef.jfsd.springboot.model.Employee;
import com.klef.jfsd.springboot.model.Questionbank;
public interface AdminService
{
	public List<Employee> viewallemps();
	public String deleteemp(int eid);
	public Employee viewempbyid(int eid);
	public Admin checkadminlogin(String username,String pwd);
	public String addQuestion(Questionbank q);
	
	public List<Questionbank> viewallquestions();
	public String addCourse(Course c);
	public List<Course> viewallcourses();
	
}
