package com.klef.jfsd.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Course;
import com.klef.jfsd.springboot.model.Employee;
import com.klef.jfsd.springboot.model.Questionbank;
import com.klef.jfsd.springboot.repository.AdminRepository;
import com.klef.jfsd.springboot.repository.CourseRepository;
import com.klef.jfsd.springboot.repository.EmployeeRepository;
import com.klef.jfsd.springboot.repository.QuestionbankRepository;
@Service
public class AdminServiceImpl implements AdminService
{
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private CourseRepository cr;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private QuestionbankRepository questionbankRepository;
	
	@Override
	public List<Employee> viewallemps()
	{	
		return employeeRepository.findAll();
	}

	@Override
	public String deleteemp(int eid)
	{
		Optional<Employee> obj = employeeRepository.findById(eid);
	    
	    String msg = null;
	    
	    if(obj.isPresent())
	    {
	      Employee emp = obj.get();
	      employeeRepository.delete(emp);
	      msg = "Student Deleted Successfully";
	    }
	    else
	    {
	      msg = "Student Not Found";
	    }
	    
	    return msg;

	}

	@Override
	public Admin checkadminlogin(String username, String pwd) {
		
		return adminRepository.checkadminlogin(username, pwd);
	}

	@Override
	public Employee viewempbyid(int eid) {
		
		Optional<Employee> obj = employeeRepository.findById(eid);    
	    
	    if(obj.isPresent())
	    {
	      Employee emp = obj.get();
	      return emp;
	    }
	    else
	    {
	      return null;
	    }
		
	}

	
	@Override
	public String addQuestion(@ModelAttribute("question") Questionbank q) {
		questionbankRepository.save(q);
		String msg= "added Successfully";
		return msg;
	}
  
	@Override
	public List<Questionbank> viewallquestions() {
		return questionbankRepository.findAll();
	}

	@Override
	public String addCourse(Course c) {
		 cr.save(c);
		return "course added successfully";
	}

	@Override
	public List<Course> viewallcourses() {
		return cr.findAll();
	}
	

}
