package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.model.Apply;
import com.klef.jfsd.springboot.model.Employee;

public interface EmployeeService 
{
	public String addemployee(Employee emp);
	public String updateemployee(Employee emp);
	public Employee viewemployeebyid(int eid);
	public Employee checkemplogin(String email,String pwd);
	public String applyexam(Apply app);
	public List<Apply> viewallexams();
}
